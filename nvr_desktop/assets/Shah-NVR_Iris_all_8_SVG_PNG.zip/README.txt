SHAH-NVR — EIGHT IRIS VARIANTS

Eight bespoke Iris/aperture logo variations for the Shah-NVR software.

Each variation includes:
  *_icon.svg       scalable vector app icon
  *_icon_512.png   high resolution app icon, transparent? NO: dark rounded-square background
  *_wordmark.svg   icon + Shah-NVR horizontal product lockup

01 IRIS FLOW    — smooth six-blade aqua shutter; natural update of the original
02 PURE IRIS    — clean, five-blade flat optics with no recording dot
03 NOVA IRIS    — tech-neon aqua, lilac, fine precision details
04 HEX IRIS     — amber six-blade shutter inside hexagonal lens enclosure
05 BLADE IRIS   — seven-blade purple-blue iris; bold and sculptural
06 SCAN IRIS    — optics with scanning crosshairs, mint and evergreen
07 SLATE IRIS   — grayscale monochrome, premium and understated
08 NORD IRIS    — the original Nord palette (#88c0d0 / #bf616a), modernized

All icon SVGs use 128x128 viewBox and scale to any size.
The wordmark relies on installed Inter/Lato/Arial font, so convert text to outlines for pixel-perfect cross-platform use.
Recommended candidates to refine: #01 for a faithful update, #02 for minimal UX, #08 for the closest palette fit.
