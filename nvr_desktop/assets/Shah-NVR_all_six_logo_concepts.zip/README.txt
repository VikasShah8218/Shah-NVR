SHAH-NVR — SIX ORIGINAL LOGO DIRECTIONS

Each concept includes:
  *_icon.svg             editable vector app icon, 256 x 256
  *_icon_512.png         ready-to-preview 512px PNG
  *_wordmark.svg         product name + app icon horizontal vector

Original color suggestions and concept descriptions:
01 IRIS — aperture + active record indicator; dark navy and aqua.
02 FOCUS — four focus brackets, a central lens, a red recording marker.
03 MONOGRAM — stylized S, violet with icy blue accent.
04 MULTIVIEW — 2x2 CCTV/NVR tiles, sky blue, red recording marker.
05 SENTINEL — shield + camera, warm peach on plum.
06 PULSE — streaming signal arcs and play mark, periwinkle.

All assets are vector-based. Resize to 32x32 for application icons or
use the wordmark in software splash screens and documentation.
The SVG wordmarks use text elements (Inter with Arial fallback).
For exact typography between machines, convert text to outlines before production.
